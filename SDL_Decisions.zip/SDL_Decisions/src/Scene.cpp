#include "Scene.h"

using namespace std;

Scene::Scene()
{
}


Scene::~Scene()
{
}

void Scene::update(float dtime,SDL_Event *event)
{
}


void Scene::draw()
{
}

const char* Scene::getTitle()
{
	return "";
}